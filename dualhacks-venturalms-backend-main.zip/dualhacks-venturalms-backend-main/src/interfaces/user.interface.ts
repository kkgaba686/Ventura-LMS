export default interface UserDetailsRes {
    name: string;
    id: string;
    email: string;
}
