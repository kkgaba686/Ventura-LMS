type studentIdObj = {
    studentId: string;
}

export default interface UserIdChunk extends Array<studentIdObj> { }