# Official Repo of VenturaLMS

Backend Code:
https://github.com/Ninjagor/dualhacks-venturalms-backend
