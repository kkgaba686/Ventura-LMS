import React, { useState, useEffect } from "react";
import { useOnMountUnsafe } from "../../../functions/useOnMountUnsafe";

const ClassOverview = () => {
    return (
        <>
        </>
    )
}


export default ClassOverview;