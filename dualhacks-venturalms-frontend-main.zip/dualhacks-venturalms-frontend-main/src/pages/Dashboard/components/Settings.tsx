import React from 'react';

const Settings = () => {
  return <div>Settings Content</div>;
};

export default Settings;